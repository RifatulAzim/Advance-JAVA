package com.util;

public interface SortUtils {

    public static final int FIRST_NAME = 1;
    public static final int LAST_NAME = 2;
}